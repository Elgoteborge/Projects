# License

Copyright © Nejla AB, 2021-2023.

This project (vite-vue-template) is licensed under [Public Domain Mark
1.0](https://creativecommons.org/publicdomain/mark/1.0/).
